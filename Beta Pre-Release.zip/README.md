# Pixel-Car-RACIST
Pee 1 Term 2 Project Rod for J.Karn LOVE ARJARN NA KUB JUBๆ 

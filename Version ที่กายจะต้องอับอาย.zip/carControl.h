#ifndef CARCONTROL_H_INCLUDED
#define CARCONTROL_H_INCLUDED

#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <iostream>
#include <cstdlib>
#include <ctime>
#include <string>
#include <cmath>

using namespace std;
using namespace sf;

class Car{  //Car class
private:
    double x,y,speed,dist; //Car position X and Y. Car speed. Distance traveled at a time.
    int playerNO; //Player number 1 or 2
    bool state; //Tells you if the button is held.
public:
    Car(int,double);
    double go(double);
    vector<double> position();
    double showDist();
    double showSpeed();
};

Car::Car(int number,double h){ //Set player car
    playerNO = number;
    speed = 0;
    dist = 0;
    state = 0;
    y = h/2-100;
    if(playerNO == 1) x = 250;
    if(playerNO == 2) x = 700;

}

double Car::go(double dt){ //How fast and far go. When key is pressed cat go faster
    double lastSpeed = speed;
    if(playerNO == 1){
        if(Keyboard::isKeyPressed(Keyboard::A) && state == 0) {speed += 1.3;state = 1;}
        else if(!Keyboard::isKeyPressed(Keyboard::A)) state = 0;
    }
    if(playerNO == 2){
        if(Keyboard::isKeyPressed(Keyboard::L) && state == 0) {speed += 1.3;state = 1;}
        else if(!Keyboard::isKeyPressed(Keyboard::L)) state = 0;
    }
    dist = 0.5 * (lastSpeed + speed) * dt;
    speed -= 0.1*dt;
    if(speed <= 0) speed = 0;
    cout << dist << endl;
    return dist;
}

vector<double> Car::position(){ //Gives the X and Y position of the car.
    vector<double> a = {x,y};
    return a;
}

double Car::showDist(){ //gives the distance the car has traveled at the time.
    return dist;
}

double Car::showSpeed(){ //Gives the speed of a cat at the time.
    return speed;
}

#endif  CARCONTROL_H_INCLUDED
